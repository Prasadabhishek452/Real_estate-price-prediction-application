# from django.urls import path
# from myapp import views

# urlpatterns = [
#     path('output/', views.OutputView.as_view(), name='output'),
#     path('home/', views.HomePageView.as_view(), name='home'),
#     path('predict/', views.PredictView.as_view(), name='predict'),
#     path('prediction/', views.PredictionView.as_view(), name='prediction'),
#     path('signup/', views.SignupView.as_view(), name='signup'),
#     path('login/', views.LoginView.as_view(), name='login'),
#     path('logout/', views.LogoutView.as_view(), name='logout'),
#     path('forgot-password/', views.ForgotPasswordView.as_view(), name='forgot_password'),
#     path('otp-verification/', views.OtpVerificationView.as_view(), name='otp_verification'),
#     path('reset-password/<str:email>/', views.ResetPasswordView.as_view(), name='reset_password'),
# ]
